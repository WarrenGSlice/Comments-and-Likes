<?php
    //**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/12/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //*****Searching Functions*************/
require_once 'database.php';
include ('person.php');
$published = '1';

class UserDataService {
    
   /* function findByTitle($n){
        // returns an array of persons

        $db = new Database();
        
        // testing
        echo "testing the db data<br>";
        print_r($db);
        
        echo "<br>I am searching for " . $n . "<br>";
        
        /*$sql_query = "SELECT id, title, image, body FROM posts WHERE title LIKE '%$n%'";
        
        $connection = $db->getConnection();
        
        
        $result = $connection->query($sql_query);
        
        if(!$result) {
            echo " assume the SQL statement has an error ";
            return null;
            exit;
        }
        
        if ($result->num_rows == 0) {
            return null;
        }else{
            echo "I found " . $result->num_rows . " results!<br>";
            
            $post_array = array();
            
            while ($post = $result->fetch_assoc()) {
                //print_r($person);
                //echo "<br>";
                
                //echo "Person id = " . $person['id'] . " NAME = " . $person['FIRST_NAME'] . " last name = " . $person['LAST_NAME'] . "<br>";
                array_push($post_array, $post);
            }
            return $post_array;
        }
    }*/



    /*function getPublishedPosts() {
    // use global $conn object in function
        global $conn;
        $sql = "SELECT * FROM posts WHERE published=true";
        $result = mysqli_query($conn, $sql);
        // fetch all posts as an associative array called $posts
        $posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

        $final_posts = array();
        foreach ($posts as $post) {
            $post['topic'] = getPostTopic($post['id']); 
            array_push($final_posts, $post);
        }
        return $final_posts;
    }*/

    function searchPosts($n)
{
    $db = new Database();
    $connection = $db->getConnection();
    // testing
        //echo "testing the db data<br>";
        /*print_r($db);*/
        
        /*echo "<br>I am searching for " . $n . "<br>";*/

    $sql_query = "SELECT id, title, body, image, published, slug, user_id, views, created_at, updated_at FROM completeblogphp.posts WHERE title LIKE '%$n%'";

    $result = $connection->query($sql_query);

    /*if(!$stmt) {
            echo " binding error ";
            exit;
    }
    //bind params
    $like_n = "5" . $n . '%';
    $stmt->bind_param("s", $like_n);
    //execute query
    $stmt->execute();
    // get results
    $result = $stmt->get_result();*/

    if(!$result ){
        echo "problem with sql statement";
        return null;
        exit;
    }

    if($result->num_rows == 0){
        return null;
    }else{
        $blog_array = array();

        while($blog = $result->fetch_assoc()){
            /*print_r($blog);
            echo "blog title= " . $blog['title'];*/
            array_push($blog_array, $blog);
        }
        return $blog_array;
    }



    /*$stmt = executeQuery($sql, ['published' => 1, 'title' => $match, 'body' => $match]);
    $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);


        

        if ($records->num_rows == 0) {
            return null;  
        }else{
            echo "I found " . $records->num_rows . " results!<br>";
            
            $post_array = array();
            
            while ($post = $records->fetch_assoc()) {
                //print_r($person);
                //echo "<br>";
                
                //echo "Person id = " . $person['id'] . " NAME = " . $person['FIRST_NAME'] . " last name = " . $person['LAST_NAME'] . "<br>";
                array_push($post_array, $post);
            }
        return $post_array;
        }*/



}
    
   /* function findByBody($n){
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("SELECT *FROM posts WHERE body LIKE '%$n%'");
        
        if (!$stmt){
            echo "Something wrong in the binding process. sql error?";
            exit;
        }
        /* bind parameters for markers 
        $like_n = "5" . $n . "%";
        $stmt->bind_param("s", $like_n);
        
        /*execute query
        $stmt->execute();
        
        // get results
        $result = $stmt->get_result();
        
        if(!$result){
            echo "assume the SQL statement has an error";
            return null;
            exit;
        }
        
        if($result->num_rows == 0){
            return null;
        }else{
            $post_array = array();
            
            while($post = $result->fetch_assoc()){
            array_push($post_array, $post);
            }
            return $post_array;
        }
        
    }
    
    function findById($id){
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("SELECT * FROM posts WHERE id = '?' LIMIT 1");
        
        if (!$stmt){
            echo "Something wrong in the binding process. sql error?";
            exit;
        }
        /* bind parameters for markers 
        //$like_n = "%" . $id . "%";
        $stmt->bind_param("s");
        
        /*execute query
        $stmt->execute();
        
        // get results
        $result = $stmt->get_result();
        
        if(!$result){
            echo "assume the SQL statement has an error";
            return null;
            exit;
        }
        
        if($result->num_rows == 0){
            return null;
        }else{
            $post_array = array();
            
            while($post = $result->fetch_assoc()){
                array_push($post_array, $post);
            }
            return $post_array;
        }
        
    }
    
    function deleteItem($id){
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("DELETE FROM posts WHERE id = '?' LIMIT 1");
        
        if (!$stmt){
            echo "Something wrong in the binding process. sql error?";
            exit;
        }
        /* bind parameters for markers *
        //$like_n = "%" . $id . "%";
        $stmt->bind_param("s");
        
        /*execute query*
        $stmt->execute();

        // get results
        if($stmt->affected_rows > 0) {
            return true;
        }else{
            return false;
        }
        
    }
    
    function updateOne($id, $post){
        $db = new Database();
        $connection = $db->getConnection();
        $stmt = $connection->prepare("UPDATE posts SET title = ?, body = ? WHERE id = '?' LIMIT 1");
        
        if (!$stmt){
            echo "Something wrong in the binding process. sql error?";
            exit;
        }
        /* bind parameters for markers *

        $tn = $post->getTitle();
        $bn = $post->getBody();
        $stmt->bind_param("ssi", $tn, $bn, $id);
        
        /*execute query*
        $stmt->execute();
        
        // get results
        if ($stmt->affected_rows > 0){
            return true;
        }else{
            return false;
        }
        
    }*/
}


?>