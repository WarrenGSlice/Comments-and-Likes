    <!--Warren Peterson-03/20/2020-->
    <!--GCU__CST_126__Blog Project-->
    <!--This is my own work-->
    
    <!--Menu Element-->
<div class="menu">
	<div class="card">
		<div class="card-header">
			<h2>Admin Actions</h2>
		</div>
		<div class="card-content">
			<a href="<?php echo BASE_URL . 'create_post.php' ?>">Create Posts</a>
			<a href="<?php echo BASE_URL . 'posts.php' ?>">Manage Posts</a>
			<a href="<?php echo BASE_URL . 'users.php' ?>">Manage Users</a>
			<a href="<?php echo BASE_URL . 'topics.php' ?>">Manage Topics</a>
		</div>
	</div>
</div>