<!--Warren Peterson-03/20/2020--
----GCU--CST-126--Blog Project--
----This is my own work---------
--------------------------------
----Page Footer---------------->
<div class="footer">
			<p>MyViewers &copy; <?php echo $access_number; ?></p>
		</div>
		<!-- // footer -->

	</div>
	<!-- // container -->
</body>
</html>