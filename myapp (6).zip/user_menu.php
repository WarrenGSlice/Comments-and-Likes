    <!--Warren Peterson-03/20/2020-->
    <!--GCU__CST_126__Blog Project-->
    <!--This is my own work-->
    
    <!--User Menu Element-->
<div class="menu">
	<div class="card">
		<div class="card-header">
			<h2>Author Actions</h2>
		</div>
		<div class="card-content">
			<a href="<?php echo BASE_URL . 'edit_post.php' ?>">Create Post</a>
			<a href="<?php echo BASE_URL . 'user_posts.php' ?>">Manage Posts</a>
			<a href="<?php echo BASE_URL . 'edit_user.php' ?>">Manage Account</a>
		</div>
	</div>
</div>